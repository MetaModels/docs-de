<?php

/**
 * Created by e-spin Berlin.
 *
 * (c) 2025
 *
 * @author     Ingolf Steinhardt <info@e-spin.de>
 * @copyright  2025 Ingolf Steinhardt <info@e-spin.de>
 * @license    GPL-3.0-or-later
 * @filesource
 */

namespace App\EventListener;

use Contao\CoreBundle\Event\MenuEvent;
use Knp\Menu\Util\MenuManipulator;
use Symfony\Component\EventDispatcher\Attribute\AsEventListener;
use Symfony\Component\HttpFoundation\RequestStack;
use Symfony\Component\HttpFoundation\Session\Attribute\AttributeBagInterface;

#[AsEventListener(priority: -1)]
class BackendMenuListener
{
    private array $targetTypes = ['before' => 0, 'after' => 1];

    public function __construct(
        private readonly RequestStack $requestStack,
    ) {
    }

    public function __invoke(MenuEvent $event): void
    {
        $factory = $event->getFactory();
        $tree    = $event->getTree();

        if ('mainMenu' !== $tree->getName()) {
            return;
        }

        $nodeName   = 'mm-test';
        $nodeTitle  = 'Meine MM Kategorie';
        $nodeIcon   = '/files/backend/group_icon_mm-test.svg';
        $targetNode = 'content';
        $targetType = 'after';

        $categoryNode = $tree->getChild($nodeName);
        if (!$categoryNode) {
            $sessionBag  = $this->requestStack->getSession()->getBag('contao_backend');
            $status      = ($sessionBag instanceof AttributeBagInterface) ? $sessionBag->get('backend_modules') : [];
            $isCollapsed = ($status[$nodeName] ?? 1) < 1;

            $categoryNode = $factory
                ->createItem($nodeName)
                ->setLabel($nodeTitle)
                ->setUri('/contao?mtg=' . $nodeName)
                ->setLinkAttribute('class', 'group-' . $nodeName)
                ->setLinkAttribute('title', $nodeTitle)
                ->setLinkAttribute('data-action', 'contao--toggle-navigation#toggle:prevent')
                ->setLinkAttribute('data-contao--toggle-navigation-category-param', $nodeName)
                ->setLinkAttribute('aria-controls', $nodeName)
                ->setLinkAttribute('aria-expanded', $isCollapsed ? 'false' : 'true')
                ->setChildrenAttribute('id', $nodeName)
                ->setLinkAttribute('style', \sprintf('background: url(%s) 3px 2px no-repeat;', $nodeIcon))
                ->setExtra('translation_domain', false);

            if ($isCollapsed) {
                $categoryNode->setAttribute('class', 'collapsed');
            }

            $tree->addChild($categoryNode);

            $targetPosition = \array_search($targetNode, \array_keys($tree->getChildren()), true);
            $targetPosition = false === $targetPosition ? 0 : $targetPosition + $this->targetTypes[$targetType];
            $manipulator    = new MenuManipulator();
            $manipulator->moveToPosition($categoryNode, $targetPosition);
        }
    }
}
